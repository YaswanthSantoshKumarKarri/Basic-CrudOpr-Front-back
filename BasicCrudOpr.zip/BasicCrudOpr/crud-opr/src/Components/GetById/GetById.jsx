import React, { useState } from 'react'
import CrudServices from '../../Services/CrudOpr/CrudServices';

const GetById = () => {
  const [dataFetchedById,setDataFetchedById]=useState({});

  let var1=0;
  const handleChange=(e)=>{
    var1=e.target.value;
  }
  const handleSearchSubmit=()=>{
    CrudServices.getUsersById(var1).then(Response=>{
      console.log(Response.data);
      setDataFetchedById(Response.data);
    })
  }

  return (
    <div>
      <input type="number" onChange={handleChange} name="id"/>
      <input type="submit" onClick={handleSearchSubmit} value="submit" />
      <div className="fetchedData">
      <div>
      <h1>Table Data</h1>
      <div className="table" style={{display:'flex',alignItems:'center',justifyContent:'center'}}>
      <table style={{border:'2px solid black'}}>
        <thead >
          <tr>
          <th>User Id</th>
            <th>User Name</th>
            <th>User Email</th>
            <th>User number</th>
            <th>User role</th>
          </tr>
        </thead>
        <tbody>
            <tr>
              <td>{dataFetchedById.id}</td>
              <td>{dataFetchedById.name}</td>
              <td>{dataFetchedById.email}</td>
              <td>{dataFetchedById.number}</td>
              <td>{dataFetchedById.role}</td>
            </tr>
        </tbody>
      </table>
      </div>
      </div>
      </div>
    </div>
  )
}

export default GetById