import React from 'react'

const UpdateById = () => {
  return (
    <div>UpdateById</div>
  )
}

export default UpdateById