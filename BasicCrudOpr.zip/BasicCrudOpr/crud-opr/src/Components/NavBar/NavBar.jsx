import React from 'react';
import {Link} from 'react-router-dom';

const NavBar = () => {
  return (
    <>
        <ul>
            <li><Link to="/Post">Post</Link></li>
            <li><Link to="/GetAll">GetAll</Link></li>
            <li><Link to="/GetById">GetById</Link></li>
            <li><Link to="/UpdateById">UpdateById</Link></li>
            <li><Link to="/DeleteById">DeleteById</Link></li>
        </ul>
    </>
  )
}

export default NavBar