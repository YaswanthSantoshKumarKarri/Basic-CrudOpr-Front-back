import React, { useState } from 'react'
import CrudServices from '../../Services/CrudOpr/CrudServices';

const DeleteById = () => {
  const [messegeFetched,setMessegeFetched]=useState('');

  let var1=0;
  const handleChange=(e)=>{
    var1=e.target.value;
  }
  const handleSearchSubmit=()=>{
    CrudServices.deleteUserById(var1).then(Response=>{
      console.log(Response.data);
      setMessegeFetched(Response.data);
    })
  }
  return (
    <div>
      <input type="number" onChange={handleChange} name="id"/>
      <input type="submit" onClick={handleSearchSubmit} value="submit" />
      <div className="messageFetched">
      </div>
    </div>
  )
}

export default DeleteById