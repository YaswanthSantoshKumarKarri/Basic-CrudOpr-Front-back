import React, { useEffect, useState } from 'react'
import CrudServices from '../../Services/CrudOpr/CrudServices';

const GetAll = () => {
  const [dataFetched, setDataFetched] = useState([]);
  useEffect(() => {
    setTimeout(() => {
      CrudServices.getAllUsers().then(Response=>{
        setDataFetched(Response.data)
      })
    }, 10000);
  });
  return (
    <>
      <div>
      <h1>Table Data</h1>
      <div className="table" style={{display:'flex',alignItems:'center',justifyContent:'center'}}>
      <table style={{border:'2px solid black'}}>
        <thead >
          <tr>
          <th>User Id</th>
            <th>User Name</th>
            <th>User Email</th>
            <th>User number</th>
            <th>User role</th>
          </tr>
        </thead>
        <tbody>
          {dataFetched.map((row, index) => (
            <tr key={index}>
              <td>{row.id}</td>
              <td>{row.name}</td>
              <td>{row.email}</td>
              <td>{row.number}</td>
              <td>{row.role}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
      
    </div>
    </>
  )
}

export default GetAll