import React, { useState } from 'react';
import CrudServices from '../../Services/CrudOpr/CrudServices';

const Post = () => {
  const [userData, setUserData] = useState({
    name: '',
    number: '',
    email: '',
    password: '',
    role: ''
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setUserData({
      ...userData,
      [name]: value
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    CrudServices.saveAuth(userData).then(Response=>{
      console.log(Response.data);
    }).catch(error => {
      console.error('Error:', error);
    });
  };

  return (
    <form style={{textAlign: 'center'}} onSubmit={handleSubmit}>
      <input type="text" onChange={handleChange} name='name' placeholder='Please enter Name' /><br/>
      <input type="number" onChange={handleChange} name='number' placeholder='Mobile' /><br/>
      <input type="email" onChange={handleChange} name='email' placeholder='Email' /><br/>
      <input type="password" onChange={handleChange} name='password' placeholder='Password' /><br/>
      <input type="password" onChange={handleChange} name='confirmPassword' placeholder='Confirm Password' /><br/>
      <input type="radio" onChange={handleChange} name="role" value="User" />
      <label htmlFor="role">User</label>
      <input type="radio" onChange={handleChange} name="role" value="Admin" />
      <label htmlFor="role">Admin</label><br/>
      <button type="submit">Submit</button>
    </form>
  );
};

export default Post;
