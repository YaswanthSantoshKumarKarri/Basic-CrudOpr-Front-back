import React from 'react';
import './App.css';
import { Routes, Route } from "react-router-dom";
import Post from './Components/Post/Post';
import GetAll from './Components/GetAll/GetAll'
import GetById from './Components/GetById/GetById'
import UpdateById from './Components/UpdateById/UpdateById'
import DeleteById from './Components/DeleteById/DeleteById'
import NavBar from './Components/NavBar/NavBar';

function App() {
  return (
    <div className="App">
      <NavBar/>
      <Routes>
        <Route path='/Post' element={<Post/>} />
        <Route path='/GetAll' element={<GetAll/> } />
        <Route path='/GetById' element={<GetById/>} />
        <Route path='/UpdateById' element={<UpdateById/>} />
        <Route path='/DeleteById' element={<DeleteById/>} />
      </Routes>
    </div>
  );
}

export default App;
