import axios from "axios";

const REVIEW_API_BASE_URL="http://localhost:8080/api/users";

class AdminAuthService{
    saveAuth(UserformData){
        return axios.post(REVIEW_API_BASE_URL, UserformData);
    }
    getAllUsers(){
        return axios.get(REVIEW_API_BASE_URL);
    }
    getUsersById(id){
        return axios.get(REVIEW_API_BASE_URL+"/"+id);
    }
    deleteUserById(id){
        return axios.delete(REVIEW_API_BASE_URL+"/"+id);
    }
}
export default new AdminAuthService();