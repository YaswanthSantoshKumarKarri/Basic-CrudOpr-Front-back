package com.example.crudOpr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudOprApplicationTests {

	@Test
	void contextLoads() {
	}

}
