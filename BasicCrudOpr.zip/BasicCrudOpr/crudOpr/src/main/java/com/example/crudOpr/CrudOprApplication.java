package com.example.crudOpr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOprApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudOprApplication.class, args);
	}

}
